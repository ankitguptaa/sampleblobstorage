import { AzureFunction, Context } from "@azure/functions"
const { BlobServiceClient } = require("@azure/storage-blob");

const timerTrigger: AzureFunction = async function (context: Context, myTimer: any): Promise<void> {
    var timeStamp = new Date().toISOString();
    const connStr = "DefaultEndpointsProtocol=https;AccountName=pwcsamplestorageaccount;AccountKey=81FZ6sSvhnidv7/rJHrArcsdJ/TiGmejSP0gOuvg9gTji/qC7hjEBIuhCg7MKMHbYcsomcxFr+8soiAw18UZNw==;EndpointSuffix=core.windows.net";
    const blobServiceClient = BlobServiceClient.fromConnectionString(connStr);
    const containerName = "pwcdocuments";
    async function main() {
    const containerClient = blobServiceClient.getContainerClient(containerName);
    let i = 1;
    let blobs = containerClient.listBlobsFlat();
    for await (const blob of blobs) {
        console.log(`Blob ${i++}: ${blob.name}`);
    }
    }
    main();

    if (myTimer.isPastDue)
    {
        context.log('Timer function is running late!');
    }
    context.log('Timer trigger function ran!', timeStamp);
};

export default timerTrigger;
